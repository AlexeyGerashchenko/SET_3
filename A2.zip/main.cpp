#include <iostream>
#include <vector>
#include <cstdint>
#include <algorithm>
#include <random>
#include <chrono>
#include <fstream>

class ArrayGenerator {
public:
    static std::vector<int> generateRandomArray(int size, int minVal, int maxVal) {
        std::vector<int> arr(size);
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> dis(minVal, maxVal);
        for (int i = 0; i < size; ++i) {
            arr[i] = dis(gen);
        }
        return arr;
    }

    static std::vector<int> generateReverseSortedArray(int size, int minVal, int maxVal) {
        std::vector<int> arr = generateRandomArray(size, minVal, maxVal);
        std::sort(arr.begin(), arr.end(), std::greater<int>());
        return arr;
    }

    static std::vector<int> generateNearlySortedArray(int size, int minVal, int maxVal, int swapCount) {
        std::vector<int> arr = generateRandomArray(size, minVal, maxVal);
        std::sort(arr.begin(), arr.end());
        std::random_device rd;
        std::mt19937 gen(rd());
        std::uniform_int_distribution<> dis(0, size - 1);
        for (int i = 0; i < swapCount; ++i) {
            int idx1 = dis(gen);
            int idx2 = dis(gen);
            std::swap(arr[idx1], arr[idx2]);
        }
        return arr;
    }
};

void merge(const std::vector<int> &l, const std::vector<int> &r, std::vector<int> &vec) {
  size_t i = 0;
  size_t j = 0;
  while (i + j < vec.size()) {
      if (j >= r.size() || (i < l.size() && r[j] >= l[i])) {
      vec[i + j] = l[i];
      i++;
    } else {
      vec[i + j] = r[j];
      j++;
    }
  }
}

void mergeSort(std::vector<int>& arr) {
    if (arr.size() <= 1) return;
    size_t mid = arr.size() / 2;
    std::vector<int> left(arr.begin(), arr.begin() + mid);
    std::vector<int> right(arr.begin() + mid, arr.end());
    mergeSort(left);
    mergeSort(right);
    merge(left, right, arr);
}

void insertion_sort(std::vector<int>& vec) {
  for (int i = 1; i < vec.size(); ++i) {
    int j = i - 1;
    int key = vec[i];
    while (j >= 0 && vec[j] > key) {
      vec[j + 1] = vec[j];
      --j;
    }
    vec[j + 1] = key;
  }
}


void merge_insertion_sort(std::vector<int> &vec) {  // NOLINT
  if (vec.size() <= 100) {
    insertion_sort(vec);
    return;
  }
  std::vector<int> lVec(vec.size() / 2);
  std::vector<int> rVec((vec.size() + 1) / 2);
  std::copy(vec.begin(), vec.begin() + lVec.size(), lVec.begin());
  std::copy(vec.begin() + lVec.size(), vec.end(), rVec.begin());
  merge_insertion_sort(lVec);
  merge_insertion_sort(rVec);
  merge(lVec, rVec, vec);
}

class SortTester {
public:
    static long long measureTime(std::vector<int>& arr) {
        auto start = std::chrono::high_resolution_clock::now();
        mergeSort(arr);
        auto elapsed = std::chrono::high_resolution_clock::now() - start;
        return std::chrono::duration_cast<std::chrono::microseconds>(elapsed).count();
    }
};

class HybridSortTester {
public:
    static long long measureTime(std::vector<int>& arr, int threshold) {
        auto start = std::chrono::high_resolution_clock::now();
        merge_insertion_sort(arr);
        auto elapsed = std::chrono::high_resolution_clock::now() - start;
        return std::chrono::duration_cast<std::chrono::microseconds>(elapsed).count();
    }
};

int main() {
    const int minSize = 500;
    const int maxSize = 10000;
    const int step = 100;
    const int minVal = 0;
    const int maxVal = 6000;
    const int swapCount = 10;

    std::ofstream outFile("/Users/alexeygerashchenko/Downloads/results_100.csv");
    outFile << "Size,RandomMergeSort,ReverseMergeSort,NearlySortedMergeSort,RandomHybridSort,ReverseHybridSort,NearlySortedHybridSort\n";

    for (int size = minSize; size <= maxSize; size += step) {
        std::vector<int> randomArr;
        std::vector<int> reverseArr;
        std::vector<int> nearlySortedArr;

        long long randomMergeTime = 0;
        long long reverseMergeTime = 0;
        long long nearlySortedMergeTime = 0;

        long long randomHybridTime = 0;
        long long reverseHybridTime = 0;
        long long nearlySortedHybridTime = 0;
        
        for (int i = 0; i < 10; ++i) {
            randomArr = ArrayGenerator::generateRandomArray(size, minVal, maxVal);
            reverseArr = ArrayGenerator::generateReverseSortedArray(size, minVal, maxVal);
            nearlySortedArr = ArrayGenerator::generateNearlySortedArray(size, minVal, maxVal, swapCount);
            randomMergeTime += SortTester::measureTime(randomArr);
            reverseMergeTime += SortTester::measureTime(reverseArr);
            nearlySortedMergeTime += SortTester::measureTime(nearlySortedArr);
            randomHybridTime += HybridSortTester::measureTime(randomArr, 10);
            reverseHybridTime += HybridSortTester::measureTime(reverseArr, 10);
            nearlySortedHybridTime += HybridSortTester::measureTime(nearlySortedArr, 10);
        }
        

        outFile << size << ","
                << randomMergeTime / 10 << ","
                << reverseMergeTime / 10 << ","
                << nearlySortedMergeTime  / 10 << ","
                << randomHybridTime / 10 << ","
                << reverseHybridTime / 10 << ","
                << nearlySortedHybridTime / 10 << "\n";
    }

    outFile.close();
    return 0;
}
